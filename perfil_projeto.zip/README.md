# Projeto de Perfil Pessoal

Este repositório foi criado como parte do curso de desenvolvimento web. O objetivo é criar uma página de perfil pessoal utilizando HTML5 semântico e CSS moderno. A estrutura inclui seções como "Sobre mim", "Habilidades", "Projetos" e "Contato". O foco está no uso de boas práticas de marcação e estilização, incluindo responsividade, Flexbox/Grid, e pseudo-elementos.
